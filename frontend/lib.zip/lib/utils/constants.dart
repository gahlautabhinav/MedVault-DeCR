// Backend API base URL
const String BASE_URL = 'http://10.0.2.2:3001'; // Android emulator
// change to http://localhost:3001 or LAN IP when needed
